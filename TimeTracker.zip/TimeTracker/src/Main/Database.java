package Main;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import com.microsoft.sqlserver.jdbc.SQLServerDataSource;

/**
 * Name: Database<br>
 * Abstract: Contains the database connection and utilities
 * @author Cole Whitaker
 * @version 1.0
 * @since 6/4/2025 
 */
public class Database {

	// Properties
	private static Connection m_conAdministrator;
	
	// Methods
	
	/**
	 * Name: OpenDatabaseConnectionSQLServer<br>
	 * Abstract: Get the SQL db connection
	 * @return blnResult - output for connection result
	 */
	private void OpenDatabaseConnectionSQLServer() {
		
		try {
			
			SQLServerDataSource sdsTimeTrackerDB = new SQLServerDataSource();
			sdsTimeTrackerDB.setServerName("localhost\\SQLExpress"); // SQL Express version
			sdsTimeTrackerDB.setPortNumber(1433);
			sdsTimeTrackerDB.setDatabaseName("TimeTrackerDB");
			
			// Login Type:
			
				// Windows Integrated
				//sdsTimeTrackerDB.setIntegratedSecurity(true);
				
				// OR
				
				// SQL Server
			     sdsTimeTrackerDB.setUser("sa");
				 sdsTimeTrackerDB.setPassword("");	// Empty string "" for blank password
			
			// Open a connection to the database
			m_conAdministrator = sdsTimeTrackerDB.getConnection();
		}
		catch(Exception excError) {
			
			// Display Error Message
			System.out.println("Cannot connect - error: " + excError);

			// Warn about SQL Server JDBC Drivers
			System.out.println("Make sure download MS SQL Server JDBC Drivers");
		}
	}
	
	
	
	/**
	* Name: CloseDatabaseConnection<br>
	* Abstract: Close the connection to the database
	*/ 
	private void CloseDatabaseConnection() {
		
		try {
			
			// Is there a connection object?
			if(m_conAdministrator != null) {
				
				// Yes, close the connection if not closed already
				if(m_conAdministrator.isClosed() == false) {
					
					m_conAdministrator.close();
					
					// Prevent JVM from crashing
					m_conAdministrator = null;
				}
			}
		}
		catch(Exception excError) {
			
			// Display Error Message
			System.out.println(excError);
		}
	}
	
	/**
	 * Name: insertTimeRecord<br>
	 * Abstract: Perform the uspInsertTime action on the DB
	 */
	public void insertTimeRecord( double dblInsertTime ) {
		
		OpenDatabaseConnectionSQLServer();
		
		try {
			
			String strInsert = "";
			Statement sqlCommand = null;
			
			strInsert = "EXECUTE uspInsertTime @dblTime = " + dblInsertTime;
			
			sqlCommand = m_conAdministrator.createStatement();
			sqlCommand.execute(strInsert);
		}
		catch(Exception excError) {
			
			excError.printStackTrace();
		}
		
		CloseDatabaseConnection();
	}
	
	public ArrayList<String> recieveTimeRecords( String strPrimaryKey, String strTimeColumn, String strDateColumn ) {
		
		String strSelect = "";
		Statement sqlCommand = null;
		ResultSet rstSource = null;
		int intID = 0;
		String strTime = "";
		String strDate = "";
		String strItem = "";
		ArrayList<String> timesList = new ArrayList<String>();
		
		OpenDatabaseConnectionSQLServer();
		
		try {
			
			strSelect = "SELECT " + strPrimaryKey + ", " + strTimeColumn + ", " + strDateColumn
					+ " FROM TTimes ORDER BY " + strPrimaryKey;  
			
			sqlCommand = m_conAdministrator.createStatement();
			rstSource = sqlCommand.executeQuery(strSelect);
			
			while ( rstSource.next() == true ) {
				
				intID = rstSource.getInt(1);
				strTime = rstSource.getString(2);
				strDate = rstSource.getString(3);
				strDate = strDate.substring(0, strDate.indexOf(" "));
				
				if ( intID < 10 ) {
					
					strItem = intID + "              " + strTime + "       " + strDate;
				}
				else {
					
					strItem = intID + "            " + strTime + "       " + strDate;
				}
				timesList.add(strItem);
			}
		}
		catch(Exception excError) {
			
			excError.printStackTrace();
		}
		finally {
			
			CloseDatabaseConnection();
		}
		
		return timesList;
	}
}
