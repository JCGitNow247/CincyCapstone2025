package Main;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JToggleButton;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import com.formdev.flatlaf.FlatClientProperties;
import com.formdev.flatlaf.FlatDarculaLaf;
import com.formdev.flatlaf.FlatIntelliJLaf;

import Icons.DarkLightIcon;
import Icons.LoadingSpinner;

/**
 * Name: TrackerGUI<br>
 * Abstract: Creates the GUI for the application
 * @author Cole Whitaker
 * @version 1.0
 * @since 6/2/2025
 */
public class TrackerGUI implements ActionListener{
	
	// Define class properties
	private long m_lngStartTime = 0;
	private double m_dblTotalHours = 0;
	
	JFrame frame;
	
	// Define the JLabels
	JLabel lblTimeOutput, lblTrackingIcon, lblTrackingIconMessage,
		   lblSuccessMessage;
	
	// Define the JButtons
	JButton btnBeginTracking, btnStopTracking, btnAddTime, btnViewTimes;
	
	// Define the JToggleButton
	JToggleButton themeSwitch;
	
	// Define the spinner
	LoadingSpinner spinner;
	
	// Define the JPanels
	JPanel timePanel, buttonPanel;
	
	/**
	 * Name: createContentPane<br>
	 * Abstract: Creates the content pane with all its controls
	 * @return MainView - output for GUI
	 * @throws NullPointerException - general exception handling
	 */
	public JPanel createContentPane() throws NullPointerException {
		
		// we create a bottom JPanel to place everything on
		JPanel MainView = new JPanel();
		MainView.setLayout(null);
		
		// Creation of a Panel to contain the time labels
		timePanel = new JPanel();
		timePanel.setLayout(null);
		timePanel.setLocation(0,20);
		timePanel.setSize(250,50);
		MainView.add(timePanel);
		
		// Create the Time label
		lblTimeOutput = new JLabel("");
		lblTimeOutput.setLocation(0,5);
		lblTimeOutput.setSize(160,30);
		lblTimeOutput.setHorizontalAlignment(0);
		//lblTimeOutput.setForeground(Color.RED);
		timePanel.add(lblTimeOutput);
		
		// create the tracking spinner
		spinner = new LoadingSpinner();
		spinner.setBounds(115,0,40,40);
		spinner.setVisible(false);
		timePanel.add(spinner);
		
		// Create the TrackingIconMessage
		lblTrackingIconMessage = new JLabel("Tracking Time:");
		lblTrackingIconMessage.setLocation(15,10);
		lblTrackingIconMessage.setSize(120,20);
		lblTrackingIconMessage.setHorizontalTextPosition(0);
		//lblTrackingIconMessage.setForeground(Color.RED);
		lblTrackingIconMessage.setVisible(false);
		timePanel.add(lblTrackingIconMessage);
		
		// Create the SuccessMessage
		lblSuccessMessage = new JLabel("");
		lblSuccessMessage.setLocation(70, 10);
		lblSuccessMessage.setSize(120,20);
		lblSuccessMessage.setHorizontalAlignment(0);
		//lblSuccessMessage.setForeground(Color.RED);
		lblSuccessMessage.setVisible(false);
		timePanel.add(lblSuccessMessage);
		
		// creation of a panel to contain all the JButtons
		buttonPanel = new JPanel();
		buttonPanel.setLayout(null);
		buttonPanel.setLocation(10,80);
		buttonPanel.setSize(260,120);
		MainView.add(buttonPanel);
		
		// Create the button for the Start Tracking click
		btnBeginTracking = new JButton("Start Tracking");
		btnBeginTracking.setLocation(0,0);
		btnBeginTracking.setSize(120,30);
		btnBeginTracking.addActionListener(this);
		buttonPanel.add(btnBeginTracking);
		
		// create the button for the Stop Tracking click
		btnStopTracking = new JButton("Stop Tracking");
		btnStopTracking.setLocation(130,0);
		btnStopTracking.setSize(120,30);
		btnStopTracking.addActionListener(this);
		btnStopTracking.setEnabled(false);
		buttonPanel.add(btnStopTracking);
		
		// create the button for the Add Time click ([+])
		ImageIcon plusSymbol = new ImageIcon("Images/Plus_Symbol_01.png");
		btnAddTime = new JButton(plusSymbol);
		btnAddTime.setLocation(170,5);
		btnAddTime.setSize(30,30);
		btnAddTime.addActionListener(this);
		btnAddTime.setToolTipText("Add Time");
		btnAddTime.setVisible(false);
		timePanel.add(btnAddTime);
		
		// create the button for the ViewTimes click
		btnViewTimes = new JButton("View Times");
		btnViewTimes.setLocation(60, 40);
		btnViewTimes.setSize(120, 30);
		btnViewTimes.addActionListener(this);
		buttonPanel.add(btnViewTimes);
		
		// Create the button for ThemeSwitch click
		themeSwitch = new JToggleButton(new DarkLightIcon());
		themeSwitch.setLocation(0, 90);
		themeSwitch.setSize(55,25);
		themeSwitch.putClientProperty(FlatClientProperties.STYLE, ""
				+ "arc:999;"
				+ "borderWidth:0;"
				+ "focusWidth:0;"
				+ "innerFocusWidth:0;");
		themeSwitch.addActionListener(this);
		buttonPanel.add(themeSwitch);
		
		// set the MainView with paint every pixel of the region with no
		// transparent pixels. Swing will clear the region to the background
		// color for you automatically.
		MainView.setOpaque(true);
		return MainView;
	}
	

	
	/**
	 * Name: actionPerformed<br>
	 * Abstract: Catches events with an ActionListener attached
	 * @param e input for ActionEvent
	 */
	public void actionPerformed(ActionEvent e) {
		
		if ( e.getSource() == btnBeginTracking ) {
			
			lblTimeOutput.setText("");
			lblSuccessMessage.setVisible(false);
			lblTrackingIconMessage.setVisible(true);
			spinner.setVisible(true);
			btnAddTime.setVisible(false);
			btnBeginTracking.setEnabled(false);
			btnStopTracking.setEnabled(true);
			m_lngStartTime = System.currentTimeMillis();
		}
		
		if ( e.getSource() == btnStopTracking ) {
			
			String strOutput = "";
			DecimalFormat df = new DecimalFormat("0.00");
			
			lblTrackingIconMessage.setVisible(false);
			spinner.setVisible(false);
			btnStopTracking.setEnabled(false);
			
			long lngElapsedTime = System.currentTimeMillis() - m_lngStartTime;

			m_dblTotalHours = (double)lngElapsedTime / ( 60 * 60 * 1000 );
			
			strOutput = df.format(m_dblTotalHours);
			
			lblTimeOutput.setText("Time tracked: " + strOutput + " hours");
			lblTimeOutput.setVisible(true);
			
			btnAddTime.setVisible(true);
			
			btnBeginTracking.setEnabled(true);	
		}
		
		if ( e.getSource() == btnAddTime ) {
			
			DecimalFormat df = new DecimalFormat("0.00");
			int intDialogResult = 0;
			
			intDialogResult = JOptionPane.showConfirmDialog(timePanel, "Add " + df.format(m_dblTotalHours) + " hours?",
															"Confirmation", JOptionPane.YES_NO_OPTION);
			
			if ( intDialogResult == JOptionPane.YES_OPTION ) {
				
				Database db = new Database();
				db.insertTimeRecord(m_dblTotalHours);
				lblSuccessMessage.setText("Time Added");
				lblSuccessMessage.setVisible(true);
			}
			else {
				
				lblSuccessMessage.setText("Time Discarded");
				lblSuccessMessage.setVisible(true);
			}
			
			lblTimeOutput.setVisible(false);
			btnAddTime.setVisible(false);
		}
		
		if( e.getSource() == btnViewTimes ) {
			
			TimeViewer GUI = new TimeViewer(themeSwitch);
			
			Window parentFrame = frame;

			// schedule a job for the event-dispatching thread:
			// creating and showing this application's GUI.
			SwingUtilities.invokeLater(new Runnable() {
				
				public void run() {
					
					// execute createAndShowGUI
					GUI.createAndShowGUI(parentFrame);
				}
			});
		}
		
		if( e.getSource() == themeSwitch ) {
			
			try {
				
				if( themeSwitch.isSelected() ) {
					
					UIManager.setLookAndFeel(new FlatDarculaLaf());
				}
				else {
					
					UIManager.setLookAndFeel(new FlatIntelliJLaf());
				}
				
				SwingUtilities.invokeLater(() -> {
					
					for( Window window : Window.getWindows() ) {
						
						SwingUtilities.updateComponentTreeUI(window);
					}
				});
			}
			catch(Exception excError) {
				
				excError.printStackTrace();
			}
		}
	}
	
	
	
	/**
	 * Name: createAndShowGUI<br>
	 * Abstract: method to create and show the GUI
	 */
	public void createAndShowGUI() {
		
		// create the frame with Java decorations look and feel
		FlatIntelliJLaf.setup();
		UIManager.put("Component.focusWidth", 0);
		UIManager.put("Button.arc", 20);

		//JFrame.setDefaultLookAndFeelDecorated(true);
		frame = new JFrame(" Time Tracker ");
		
		// create and setup the content pane
		frame.setContentPane(this.createContentPane());
		
		// specify your option for the close button
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		// set your frame size
		frame.setSize(285,250);
		
		frame.setResizable(false);
		
		frame.setLocationRelativeTo(null);
		
		// make the frame visible
		frame.setVisible(true);
	}
	
	
}
