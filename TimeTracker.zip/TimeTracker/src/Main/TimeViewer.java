package Main;
import java.awt.Dialog;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.DefaultListModel;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JToggleButton;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import com.formdev.flatlaf.FlatClientProperties;
import com.formdev.flatlaf.FlatDarculaLaf;
import com.formdev.flatlaf.FlatIntelliJLaf;

import Icons.DarkLightIcon;

/**
 * Name: TimeViewer<br>
 * Abstract: Creates the content pane for viewing times
 * @author Cole Whitaker
 * @version 1.0
 * @since 6/4/2025
 */
public class TimeViewer implements ActionListener {

	// Define the textbox to hold times
	DefaultListModel<String> model;
	JList<String> timeArea;
	
	// Define the panel
	JPanel timePanel;
	
	// Define the JToggleButton
	JToggleButton mainThemeSwitch, themeSwitch;
	
	public TimeViewer( JToggleButton mainThemeSwitch ) {
		
		this.mainThemeSwitch = mainThemeSwitch;
	}
	
	/**
	 * Name: createAndShowGUI<br>
	 * Abstract: method to create and show the GUI
	 */
	public void createAndShowGUI(Window parent) {
		
		// create the frame with Java decorations look and feel
		UIManager.put("Component.focusWidth", 0);
		
		//JFrame.setDefaultLookAndFeelDecorated(true);
		JDialog frame = new JDialog(parent, " View Times ", Dialog.ModalityType.APPLICATION_MODAL);
		
		// create and setup the content pane
		frame.setContentPane(this.createContentPane());
		
		// specify your option for the close button
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
		// set your frame size
		frame.setSize(500,500);
		
		frame.setResizable(false);
		
		frame.setLocationRelativeTo(parent);
		
		// make the frame visible
		frame.setVisible(true);
	}
	
	/**
	 * Name: createContentPane<br>
	 * Abstract: Creates the content pane with all its controls
	 * @return MainView - output for GUI
	 * @throws NullPointerException - general exception handling
	 */
	public JPanel createContentPane() throws NullPointerException {
		
		ArrayList<String> timesList = new ArrayList<String>();
		
		// we create a bottom JPanel to place everything on
		JPanel MainView = new JPanel();
		MainView.setLayout(null);
		
		// Creation of a Panel to contain the time labels
		timePanel = new JPanel();
		timePanel.setLayout(null);
		timePanel.setLocation(0,20);
		timePanel.setSize(450,450);
		MainView.add(timePanel);
		
		// Create the button for ThemeSwitch click
		themeSwitch = new JToggleButton(new DarkLightIcon());
		themeSwitch.setLocation(15, 400);
		themeSwitch.setSize(55,25);
		themeSwitch.putClientProperty(FlatClientProperties.STYLE, ""
				+ "arc:999;"
				+ "borderWidth:0;"
				+ "focusWidth:0;"
				+ "innerFocusWidth:0;");
		if( mainThemeSwitch != null ) {
			
			themeSwitch.setSelected(mainThemeSwitch.isSelected());
		}
		themeSwitch.addActionListener(this);
		timePanel.add(themeSwitch);
		
		model = new DefaultListModel<String>();
		timeArea = new JList<String>(model);
		
		Database db = new Database();
		
		timesList = db.recieveTimeRecords( "intTimeID", "dblTime", "dtmDate" );
		
		model.addElement("Item:      Time:     Date:");
		
		for ( String listItem : timesList ) {
			
			model.addElement(listItem);
		}

		JScrollPane scrollPane = new JScrollPane(timeArea);
		scrollPane.setSize(280,280);
		scrollPane.setLocation(110,50);
		timePanel.add(scrollPane);
		
		MainView.setOpaque(true);
		return MainView;
	}
	
	/**
	 * Name: actionPerformed<br>
	 * Abstract: Catches events with an ActionListener attached
	 * @param e input for ActionEvent
	 */
	public void actionPerformed(ActionEvent e) {
		
		if( e.getSource() == themeSwitch ) {
			
			boolean selected = themeSwitch.isSelected();
			
			if( mainThemeSwitch != null && mainThemeSwitch.isSelected() != selected ) {
				
				mainThemeSwitch.setSelected(selected);
			}
			
			try {
				
				if( themeSwitch.isSelected() ) {
					
					UIManager.setLookAndFeel(new FlatDarculaLaf());
				}
				else {
					
					UIManager.setLookAndFeel(new FlatIntelliJLaf());
				}
				
				SwingUtilities.invokeLater(() -> {
					
					for( Window window : Window.getWindows() ) {
						
						SwingUtilities.updateComponentTreeUI(window);
					}
				});
			}
			catch(Exception excError) {
				
				excError.printStackTrace();
			}
		}
	}
}
