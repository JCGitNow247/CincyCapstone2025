package Main;
import javax.swing.SwingUtilities;

/**
 * Name: TrackerStart<br>
 * Abstract: This is where the application will run
 * @author Cole Whitaker
 * @version 1.0
 * @since 6/2/2025
 */
public class TrackerStart extends javax.swing.JFrame {

	private static final long serialVersionUID = 1L;

	/**
	 * Name: main<br>
	 * Abstract: main entry point for program
	 * @param args input for run configs (not used)
	 */
	public static void main(String[] args) {
		
		TrackerGUI GUI = new TrackerGUI();

		// schedule a job for the event-dispatching thread:
		// creating and showing this application's GUI.
		SwingUtilities.invokeLater(new Runnable() {
			
			public void run() {
				
				// execute createAndShowGUI
				GUI.createAndShowGUI();
			}
		});
	}
}
