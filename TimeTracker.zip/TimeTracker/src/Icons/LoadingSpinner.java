package Icons;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Path2D;

public class LoadingSpinner extends JComponent implements ActionListener {

	private static final long serialVersionUID = 1L;
	
	private final Timer timer;
    private int currentFrame = 0;

    private final int spokeCount = 8;
    private final int spokeLength = 12;
    private final int spokeWidth = 6;
    private final int delay = 80; // ms per frame (~12.5 FPS)

    public LoadingSpinner() {
        setPreferredSize(new Dimension(40, 40));
        setOpaque(false);
        timer = new Timer(delay, this);
        timer.start();
    }

    private Shape createRoundedTriangle(int length, int width) {
        // Create a narrow triangle shape pointing up, with a rounded tip
        Path2D.Float triangle = new Path2D.Float();
        float halfWidth = width / 2f;
        float roundTipRadius = width / 2f;

        triangle.moveTo(0, 0); // base center bottom
        triangle.lineTo(-halfWidth, length - roundTipRadius); // bottom left
        triangle.quadTo(0, length, halfWidth, length - roundTipRadius); // rounded tip curve
        triangle.lineTo(halfWidth, 0); // bottom right
        triangle.closePath();

        return triangle;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        int w = getWidth();
        int h = getHeight();
        int outerRadius = Math.min(w, h) / 2 - 2;
        int innerRadius = outerRadius - spokeLength - 10; // spoke start distance

        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.translate(w / 2, h / 2);

        Shape spokeShape = createRoundedTriangle(spokeLength, spokeWidth);

        for (int i = 0; i < spokeCount; i++) {
            float alpha = 1.0f - ((i + spokeCount - currentFrame) % spokeCount) / (float) spokeCount;
            g2.setColor(new Color(128, 128, 128, (int) (alpha * 255)));

            g2.rotate(Math.toRadians(360.0 / spokeCount));

            // Move spokeShape up to start at innerRadius from center
            g2.translate(0, -innerRadius);
            g2.fill(spokeShape);
            g2.translate(0, innerRadius);
        }

        g2.dispose();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        currentFrame = (currentFrame + 1) % spokeCount;
        repaint();
    }
}
